﻿using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Debt
{
    /// <summary>
    /// AuditFile.xaml 的交互逻辑
    /// </summary>
    public partial class AuditFile : UserControl
    {
        private string supportId, token;
        private List<Data_View> list = new List<Data_View>();
        private int selected = 0, saved = 0;

        public string SupportId
        {
            get { return supportId; }
            set { supportId = value; }
        }

        public string Token
        {
            get { return token; }
            set { token = value; }
        }

        private string defaultDirectory = @"E:\DebtPlatform\FileRecv";
        public string DefaultDirectory
        {
            get { return defaultDirectory; }
            set { defaultDirectory = value; }
        }

        private string tempDirectory = @"E:\DebtPlatform\AppData";
        public string TempDirectory
        {
            get { return tempDirectory; }
            set { tempDirectory = value; }
        }
        public AuditFile()
        {
            InitializeComponent();
        }

        public async Task GetRemoteFileList()
        {
            try
            {
                selected = 0;
                list.Clear();
                await new HttpTask().data("token", token)
                  .data("supportId", supportId)
                  .postAsync(Url.ViewFile, OnSucceed, OnFailed);
            }
            catch (Exception ex)
            {
                probarFile.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed(string result)
        {
            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                probarFile.Visibility = Visibility.Hidden;
                return;
            }
            probarFile.Visibility = Visibility.Hidden;
            var filelist = FilesView.JsonStrToList(result);
            Dg_View.ItemsSource = null;
            if (filelist.data.Count <= 0)
            {
                Lab_Info.Content = "没有文件";
                list.Clear();
            }
            else
            {
                foreach (var item in filelist.data)
                {
                    list.Add(new Data_View(false, item));
                }
                Dg_View.ItemsSource = list;
                Dg_View.Items.Refresh();
            }
            Lab_Count.Content = list.Count + "项";
        }

        public void OnFailed()
        {
            Dg_View.ItemsSource = null;
            probarFile.Visibility = Visibility.Hidden;
            list.Clear();
            Lab_Info.Content = "没有文件";
            Lab_Count.Content = "0项";

            MessageBox.Show("请检查网络状况或本机防火墙设置", "加载文件列表失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private async void Btn_Download_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            bool isBoxDownload = true;
            if (list.Count <= 0)
            {
                Lab_Info.Content = "没有文件";
                Lab_Info.Visibility = Visibility.Visible;
                return;
            }
            if (btn.Tag == null || btn.Tag.ToString() == string.Empty)
            {
                if (selected <= 0)
                {
                    Lab_Info.Content = "请选择文件";
                    Lab_Info.Visibility = Visibility.Visible;
                    return;
                }
            }
            else
            {
                isBoxDownload = false;
            }
            if (defaultDirectory.Equals(string.Empty))
            {
                Lab_Info.Content = "请选择文件保存目录";
                Lab_Info.Visibility = Visibility.Visible;
                return;
            }
            probarFile.Visibility = Visibility.Visible;
            try
            {
                if (isBoxDownload)
                {
                    saved = selected;
                    foreach (var item in list)
                    {
                        if (item.Ischecked == true)
                        {
                            await DownloadRemoteFile(item.Onefile.id, item.Onefile.fileName);
                        }
                    }
                }
                else
                {
                    saved = 1;
                    var name = list.Find(o => o.Onefile.id == btn.Tag.ToString()).Onefile.fileName;
                    await DownloadRemoteFile(btn.Tag.ToString(), name);
                }
            }
            catch (Exception ex)
            {
                probarFile.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task DownloadRemoteFile(string id, string name)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    var response = await client.GetAsync(Url.DownloadFile + "&fileId=" + id + "&token=" + token);
                    if (response.IsSuccessStatusCode)
                    {//判断请求是否成功
                        var responseStream = response.Content.ReadAsStreamAsync().Result;
                        if (defaultDirectory.EndsWith(@"\"))
                        {
                            defaultDirectory.Trim('\\');
                        }
                        if (!Directory.Exists(defaultDirectory))
                        {
                            Directory.CreateDirectory(defaultDirectory);
                        }
                        string path = defaultDirectory + "\\" + name;
                        for (int i = 1; File.Exists(path); i++)
                        {
                            path = defaultDirectory + "\\" + System.IO.Path.GetFileNameWithoutExtension(name) + "(" + i + ")" + System.IO.Path.GetExtension(name);
                        }
                        Stream stream = new FileStream(path, FileMode.Create, FileAccess.Write);
                        byte[] bArr = new byte[1024];
                        int size = responseStream.Read(bArr, 0, bArr.Length);
                        while (size > 0)
                        {
                            stream.Write(bArr, 0, size);
                            size = responseStream.Read(bArr, 0, bArr.Length);
                        }
                        stream.Close();
                        responseStream.Close();
                        if (--saved <= 0)
                        {
                            probarFile.Visibility = Visibility.Hidden;
                            MessageBox.Show("文件下载完成", "消息提示", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    else
                    {
                        //OnFailed();
                        probarFile.Visibility = Visibility.Hidden;
                        MessageBox.Show("文件下载出错", "消息提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception ex)
                {
                    probarFile.Visibility = Visibility.Hidden;
                    MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Btn_Browse_Click(object sender, RoutedEventArgs e)
        {
            SetDefaultSaveDirectory(ref defaultDirectory);
        }

        private void SetDefaultSaveDirectory(ref string defaultDirectory)
        {
            CommonOpenFileDialog cofd = new CommonOpenFileDialog();
            cofd.IsFolderPicker = true;//设置为选择文件夹
            cofd.RestoreDirectory = true;

            if (defaultDirectory != string.Empty)
            {
                cofd.DefaultDirectory = defaultDirectory;
            }
            if (cofd.ShowDialog() == CommonFileDialogResult.Ok)
            {
                defaultDirectory = cofd.FileName;
            }
            Lab_SaveDirectory.Content = defaultDirectory;
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            var box = sender as CheckBox;
            if (box.IsChecked == true)
            {
                foreach (var item in list)
                {
                    if (item.Onefile.id.Equals(box.Tag))
                    {
                        item.Ischecked = true;
                        selected++;
                        break;
                    }
                }
            }
            else
            {
                foreach (var item in list)
                {
                    if (item.Onefile.id.Equals(box.Tag))
                    {
                        item.Ischecked = false;
                        selected--;
                        break;
                    }
                }
            }
        }

        private async void Btn_View_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            var name = list.Find(o => o.Onefile.id == btn.Tag.ToString()).Onefile.fileName;
            probarFile.Visibility = Visibility.Visible;
            await PreviewFile(btn.Tag.ToString(), name);
        }

        private async Task PreviewFile(string id, string name)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    var response = await client.GetAsync(Url.DownloadFile + "&fileId=" + id + "&token=" + token);
                    if (response.IsSuccessStatusCode)
                    {//判断请求是否成功
                        var responseStream = response.Content.ReadAsStreamAsync().Result;
                        if (tempDirectory.EndsWith(@"\"))
                        {
                            tempDirectory.Trim('\\');
                        }
                        if (!Directory.Exists(tempDirectory))
                        {
                            Directory.CreateDirectory(tempDirectory);
                        }
                        string path = tempDirectory + "\\" + name;
                        Stream stream = new FileStream(path, FileMode.Create, FileAccess.Write);
                        byte[] bArr = new byte[1024];
                        int size = responseStream.Read(bArr, 0, bArr.Length);
                        while (size > 0)
                        {
                            stream.Write(bArr, 0, size);
                            size = responseStream.Read(bArr, 0, bArr.Length);
                        }
                        stream.Close();
                        responseStream.Close();
                        probarFile.Visibility = Visibility.Hidden;
                        Process.Start(path);  //打开某个文件
                    }
                    else
                    {
                        //OnFailed();
                        probarFile.Visibility = Visibility.Hidden;
                        MessageBox.Show("文件下载出错", "消息提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception ex)
                {
                    probarFile.Visibility = Visibility.Hidden;
                    MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}

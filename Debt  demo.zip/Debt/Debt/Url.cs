﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Debt
{
    class Url
    {
        public static string UploadFile
        {
            get { return @"http://121.41.59.137/api/file.php?act=upload"; }
        }
        public static string ViewFile
        {
            get { return @"http://121.41.59.137/api/file.php?act=getFileList"; }
        }
        public static string DownloadFile
        {
            get { return @"http://121.41.59.137/api/file.php?act=download"; }
        }
        public static string DeleteFile
        {
            get { return @"http://121.41.59.137/api/file.php?act=delete"; }
        }
        public static string GetAuditedList
        {
            get { return @"http://121.41.59.137/api/audit.php?act=getAuditedList"; }
        }
        public static string GetAppliedList
        {
            get { return @"http://121.41.59.137/api/audit.php?act=getWaitList"; }
        }

        public static string AuditApply
        {
            get { return @"http://121.41.59.137/api/audit.php?act=auditApply"; }
        }

        public static string GetCompanies
        {
            get { return @"http://121.41.59.137/api/deal.php?act=getCompanies"; }
        }

        public static string ChangeUserInfo
        {
            get { return @"http://121.41.59.137/api/user.php?act=changeUserInfo"; }
        }

        public static string ResetPassword
        {
            get { return @"http://121.41.59.137/api/user.php?act=resetPassword"; }
        }

        public static string GetOperationLog
        {
            get { return @"http://121.41.59.137/api/user.php?act=getOperationList"; }
        }

    }
}

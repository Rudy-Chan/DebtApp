﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;

namespace Debt
{
    class Json
    {
        public int error { get; set; }    //错误码
        public static int JsonStrToObject(string json)
        {//反序列化
            return JsonConvert.DeserializeObject<Json>(json).error;
        }
    }

    class Error_Msg
    {
        public string msg { get; set; }  //错误信息
        public static void JsonStrToObject(string json)
        {
            var model = JsonConvert.DeserializeObject<Error_Msg>(json);
            MessageBox.Show(model.msg, "异常提醒", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    class File_Single
    {
        public string id { get; set; }
        public string fileName { get; set; }
        public string fileSize { get; set; }
        public string uploadTime { get; set; }
        public File_Single(string id, string fileName, string fileSize, string uploadTime)
        {
            this.id = id;
            this.fileName = fileName;
            this.fileSize = Data_File.ConvertSize(Convert.ToInt64(fileSize));
            this.uploadTime = uploadTime;
        }
        public static File_Single JsonStrToObject(string json)
        {
            //反序列化
            return JsonConvert.DeserializeObject<File_Single>(json);
        }
    }

    class FilesView
    {
        public List<File_Single> data { get; set; }
        public static FilesView JsonStrToList(string json)
        {
            //反序列化
            return JsonConvert.DeserializeObject<FilesView>(json);
        }
    }

    class FilesDelete
    {
        public int deletedCount { get; set; }
        public static FilesDelete JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<FilesDelete>(json);
        }
    }

    class AuditSingle
    {
        public string id { get; set; }
        public string userName { get; set; }
        public string supportId { get; set; }
        public string rank { get; set; }
        public string accepted { get; set; }
        public string remark { get; set; }
        public string auditTime { get; set; }
    }

    class AuditRecord
    {
        public List<AuditSingle> data { get; set; }
        public static AuditRecord JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<AuditRecord>(json);
        }
    }

    class ApplySingle
    {
        public string debtId { get; set; }
        public string amount { get; set; }
        public string bondInstitutionId { get; set; }
        public string debtUnitId { get; set; }
        public string debtTypeName { get; set; }
        public string relatedBank { get; set; }
        public string creditUpdateName { get; set; }
        public string applyTime { get; set; }
        public string debtStartTime { get; set; }
        public string debtEndTime { get; set; }
        public string baseInterestType { get; set; }
        public string baseInterest { get; set; }
        public string isInGov { get; set; }
        public string rateRatio { get; set; }
        public string rateAdjustType { get; set; }
        public string guarantor { get; set; }
        public string payInterestDate { get; set; }
        public string payInterestMonth { get; set; }
        public string term { get; set; }
        public string yearDay { get; set; }
        public string status { get; set; }
        public string userName { get; set; }
        public string remark { get; set; }
        public string name { get; set; }

    }

    class ApplyRecord
    {
        public List<ApplySingle> data { get; set; }
        public static ApplyRecord JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<ApplyRecord>(json);
        }
    }

    class ChangeSingle
    {
        public string changeId { get; set; }
        public string debtId { get; set; }
        public string baseInterest { get; set; }
        public string rateRatio { get; set; }
        public string debtUnitId { get; set; }
        public string adjustType { get; set; }
        public string applyTime { get; set; }
        public string changeDate { get; set; }
        public string status { get; set; }
        public string userName { get; set; }
        public string remark { get; set; }
    }

    class ChangeRecord
    {
        public List<ChangeSingle> data { get; set; }
        public static ChangeRecord JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<ChangeRecord>(json);
        }
    }

    class PaymentSingle
    {
        public string paymentId { get; set; }
        public string debtId { get; set; }
        public string amount { get; set; }
        public string payDate { get; set; }
        public string userName { get; set; }
        public string applyTime { get; set; }
        public string type { get; set; }
        public string status { get; set; }
        public string remark { get; set; }
    }

    class PaymentRecord
    {
        public List<PaymentSingle> data { get; set; }
        public static PaymentRecord JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<PaymentRecord>(json);
        }
    }


    class ReceiveSingle
    {
        public string receiveId { get; set; }
        public string debtId { get; set; }
        public string amount { get; set; }
        public string receiveDate { get; set; }
        public string userName { get; set; }
        public string applyTime { get; set; }
        public string status { get; set; }
        public string remark { get; set; }
    }

    class ReceiveRecord
    {
        public List<ReceiveSingle> data { get; set; }
        public static ReceiveRecord JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<ReceiveRecord>(json);
        }
    }

    class Operation
    {
        public string id { get; set; }
        public string operation { get; set; }
        public string userName { get; set; }
        public DateTime operationDate { get; set; }
        public string ip { get; set; }
        public string type { get; set; }
        public string name { get; set; }
    }

    class OperationLog
    {
        public string page { get; set; }
        public string totalPage { get; set; }
        public string rows { get; set; }
        public List<Operation> data { get; set; }
        public static OperationLog JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<OperationLog>(json);
        }
    }

    public class UserInfo
    {
        public string userName { get; set; }
        public string department { get; set; }
        public string rank { get; set; }
        public string companyId { get; set; }
        public string companyName { get; set; }
        public string name { get; set; }
        public string phone { get; set; }
        public string auditRank { get; set; }
        public string token { get; set; }

        public UserInfo(string userName, string department, string rank, string companyId, string companyName, string name, string phone, string auditRank, string token)
        {
            this.userName = userName;
            this.department = department;
            this.rank = rank;
            this.companyId = companyId;
            this.companyName = companyName;
            this.name = name;
            this.phone = phone;
            this.auditRank = auditRank;
            this.token = token;
        }
    }

    public class Company
    {
        public string id { get; set; }
        public string name { get; set; }
        public string parent { get; set; }
        public string materPhone { get; set; }
        public string master { get; set; }
        public string auditRank { get; set; }
        public string remark { get; set; }
    }

    public class ListCompany
    {
        public List<Company> data { get; set; }
        public static ListCompany JsonStrToList(string json)
        {
            return JsonConvert.DeserializeObject<ListCompany>(json);
        }
    }

}

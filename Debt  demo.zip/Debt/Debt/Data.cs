﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Debt
{
    class Data_File
    {
        private string id;
        private string name;
        private string directory;
        private string size;

        public string Id { get { return id; } }
        public string Name { get { return name; } }
        public string Directory { get { return directory; } }
        public string Size { get { return size; } }
        public Data_File(string id, string path)
        {
            this.id = id;
            name = System.IO.Path.GetFileName(path);
            size = ConvertSize(new FileInfo(path).Length);
            directory = System.IO.Path.GetDirectoryName(path);
        }

        public static string ConvertSize(long length)
        {
            string newSize = "";
            double size = (int)(length / 1024.0 / 1024.0 * 100) / 100.0;
            if (size < 1)
            {
                size = (int)(length / 1024.0 * 100) / 100.0;
                newSize = size + "KB";
            }
            else if (size > 1000)
            {
                size = (int)(length / 1024.0 / 1024.0 / 1024.0 * 10) / 10.0;
                newSize = size + "GB";
            }
            else
            {
                newSize = size + "MB";
            }
            return newSize;
        }
    }

    class Data_View
    {
        private bool ischecked;
        private File_Single onefile;
        public bool Ischecked 
        { 
            get { return ischecked; }
            set { ischecked = value; }
        }
        public File_Single Onefile { get { return onefile; } }
        public Data_View(bool ischecked, File_Single onefile)
        {
            this.ischecked = ischecked;
            this.onefile = onefile;
        }
    }

    class Data_AuditItem
    {
        private string type;
        private AuditSingle oneAudit;

        public string Type
        {
            get { return type; }
        }
        public AuditSingle OneAudit
        {
            get { return oneAudit; }
        }

        public Data_AuditItem(string type, AuditSingle oneAudit)
        {
            this.type = type;
            this.oneAudit = oneAudit;
        }
    }

    class Data_ApplyItem
    {
        private int rowIndex;
        private bool cb_IsChecked;
        private ApplySingle oneApply;

        public int RowIndex
        {
            get { return rowIndex; }
            set { rowIndex = value; }
        }

        public bool Cb_IsChecked
        {
            get { return cb_IsChecked; }
            set { cb_IsChecked = value; }
        }
        public ApplySingle OneApply
        {
            get { return oneApply; }
        }

        public Data_ApplyItem(int rowIndex, bool cb_IsChecked, ApplySingle oneApply)
        {
            this.rowIndex = rowIndex;
            this.cb_IsChecked = cb_IsChecked;
            this.oneApply = oneApply;
        }
    }

    class Data_ChangeItem
    {
        private int rowIndex;
        private bool cb_IsChecked;
        private ChangeSingle oneChange;

        public int RowIndex
        {
            get { return rowIndex; }
            set { rowIndex = value; }
        }

        public bool Cb_IsChecked
        {
            get { return cb_IsChecked; }
            set { cb_IsChecked = value; }
        }
        public ChangeSingle OneChange
        {
            get { return oneChange; }
        }

        public Data_ChangeItem(int rowIndex, bool cb_IsChecked, ChangeSingle oneChange)
        {
            this.rowIndex = rowIndex;
            this.cb_IsChecked = cb_IsChecked;
            this.oneChange = oneChange;
        }
    }

    class Data_PaymentItem
    {
        private int rowIndex;
        private bool cb_IsChecked;
        private PaymentSingle onePayment;

        public int RowIndex
        {
            get { return rowIndex; }
            set { rowIndex = value; }
        }

        public bool Cb_IsChecked
        {
            get { return cb_IsChecked; }
            set { cb_IsChecked = value; }
        }
        public PaymentSingle OnePayment
        {
            get { return onePayment; }
        }

        public Data_PaymentItem(int rowIndex, bool cb_IsChecked, PaymentSingle onePayment)
        {
            this.rowIndex = rowIndex;
            this.cb_IsChecked = cb_IsChecked;
            this.onePayment = onePayment;
        }
    }

    class Data_ReceiveItem
    {
        private int rowIndex;
        private bool cb_IsChecked;
        private ReceiveSingle oneReceive;

        public int RowIndex
        {
            get { return rowIndex; }
            set { rowIndex = value; }
        }

        public bool Cb_IsChecked
        {
            get { return cb_IsChecked; }
            set { cb_IsChecked = value; }
        }
        public ReceiveSingle OneReceive
        {
            get { return oneReceive; }
        }

        public Data_ReceiveItem(int rowIndex, bool cb_IsChecked, ReceiveSingle oneReceive)
        {
            this.rowIndex = rowIndex;
            this.cb_IsChecked = cb_IsChecked;
            this.oneReceive = oneReceive;
        }
    }

}

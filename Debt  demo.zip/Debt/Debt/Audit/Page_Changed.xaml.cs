﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Debt
{
    /// <summary>
    /// Page_Changed.xaml 的交互逻辑
    /// </summary>
    public partial class Page_Changed : Page
    {
        private string token;
        private string type = "C";
        private List<Data_ChangeItem> list = new List<Data_ChangeItem>();
        private List<int> list_Select = new List<int>();//保存所选记录的索引
        private int index_Select;

        public Page_Changed(string token)
        {
            this.token = token;
            InitializeComponent();
        }

        private async void Dg_DebtChanged_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Dg_DebtChanged.SelectedItem != null)
            {
                auditFile.SupportId = ((Data_ChangeItem)Dg_DebtChanged.SelectedItem).OneChange.debtId;
                auditFile.Token = token;
                auditFile.probarFile.Visibility = Visibility.Visible;
                await auditFile.GetRemoteFileList();
                Tbx_Comment.Text = string.Empty;
            }
        }

        public async Task GetRemoteApplyRecord()
        {
            try
            {
                //selected = 0;
                list.Clear();
                list_Select.Clear();
                await new HttpTask().data("token", token)
                    .data("type", type)
                    .postAsync(Url.GetAppliedList, OnSucceed_GetList, OnFailed_GetList);
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed_GetList(string result)
        {
            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                probar.Visibility = Visibility.Hidden;
                return;
            }
            probar.Visibility = Visibility.Hidden;
            var changelist = ChangeRecord.JsonStrToList(result);
            Dg_DebtChanged.ItemsSource = null;
            if (changelist.data.Count <= 0)
            {
                Lab_Info.Content = "没有记录";
                Lab_Info.Visibility = Visibility.Visible;
                list.Clear();
            }
            else
            {
                foreach (var item in changelist.data)
                {
                    list.Add(new Data_ChangeItem(list.Count, false, item));
                }
            }
            MainViewModel<Data_ChangeItem> model = new MainViewModel<Data_ChangeItem>(list);
            DataContext = model;
            Dg_DebtChanged.ItemsSource = model.FakeSource;
            Dg_DebtChanged.Items.Refresh();
        }

        public void OnFailed_GetList()
        {
            Dg_DebtChanged.ItemsSource = null;
            probar.Visibility = Visibility.Hidden;
            list.Clear();
            Lab_Info.Content = "没有记录";

            MessageBox.Show("请检查网络状况或本机防火墙设置", "加载申请记录失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Cb_Single_Click(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            int index = Convert.ToInt32(cb.Tag.ToString());   //获取该行id 

            if (cb.IsChecked == true)
            {
                list[index].Cb_IsChecked = true;
                list_Select.Add(index);  //如果选中就保存id          
            }
            else
            {
                list[index].Cb_IsChecked = false;
                list_Select.Remove(index);   //如果选中取消就删除里面的id            
            }
        }

        private async Task AuditItemPassOrReject(string supportId, string accepted)
        {
            try
            {
                string remark = Tbx_Comment.Text;
                await new HttpTask().data("supportId", supportId)
                    .data("token", token)
                    .data("remark", remark)
                    .data("accepted", accepted)
                    .postAsync(Url.AuditApply, OnSucceed_PassOrReject, OnFailed_PassOrReject);
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void Btn_Pass_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            index_Select = Convert.ToInt32(btn.Tag.ToString());   //获取该行id 
            probar.Visibility = Visibility.Visible;
            await AuditItemPassOrReject(list[index_Select].OneChange.debtId, "1");
        }

        private async void Btn_Reject_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            index_Select = Convert.ToInt32(btn.Tag.ToString());   //获取该行id 
            probar.Visibility = Visibility.Visible;
            await AuditItemPassOrReject(list[index_Select].OneChange.debtId, "0");
        }

        private void OnSucceed_PassOrReject(string result)
        {
            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                probar.Visibility = Visibility.Hidden;
                return;
            }
            probar.Visibility = Visibility.Hidden;
            Dg_DebtChanged.ItemsSource = null;
            list.RemoveAt(index_Select);
            auditFile.Dg_View.ItemsSource = null;
            Tbx_Comment.Text = string.Empty;
            if (list.Count <= 0)
            {
                Lab_Info.Content = "没有记录";
                Lab_Info.Visibility = Visibility.Visible;
            }
            else
            {
                for (int i = 0; i < list.Count; i++)
                {
                    list[i].RowIndex = i;
                }
            }
            MainViewModel<Data_ChangeItem> model = new MainViewModel<Data_ChangeItem>(list);
            DataContext = model;
            Dg_DebtChanged.ItemsSource = model.FakeSource;
            Dg_DebtChanged.Items.Refresh();
        }

        public void OnFailed_PassOrReject()
        {
            probar.Visibility = Visibility.Hidden;
            MessageBox.Show("请检查网络状况或本机防火墙设置", "审核申请记录失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Btn_Save_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int index = Convert.ToInt32(btn.Tag.ToString());
            probar.Visibility = Visibility.Visible;
            SaveSingleApply(list[index].OneChange.debtId);
        }

        private void SaveSingleApply(string key)
        {
            try
            {
                string remark = Tbx_Comment.Text;
                ConfigHelper.UpdateAppConfig(key, remark);
                probar.Visibility = Visibility.Hidden;
                Lab_Info.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                Lab_Info.Content = ex.Message;
                Lab_Info.Visibility = Visibility.Visible;
            }
        }

        private async void Btn_PassItems_Click(object sender, RoutedEventArgs e)
        {
            if (list_Select.Count <= 0)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show("请选择记录", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            foreach (var index in list_Select)
            {
                await AuditItemPassOrReject(list[index].OneChange.debtId, "1");
            }
        }

        private async void Btn_RejectItems_Click(object sender, RoutedEventArgs e)
        {
            if (list_Select.Count <= 0)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show("请选择记录", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            foreach (var index in list_Select)
            {
                await AuditItemPassOrReject(list[index].OneChange.debtId, "0");
            }
        }

        private void Btn_SaveItems_Click(object sender, RoutedEventArgs e)
        {
            if (list_Select.Count <= 0)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show("请选择记录", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string remark = Tbx_Comment.Text;
            bool saved = false;
            if (list_Select.Count > 0)
            {
                foreach (var index in list_Select)
                {
                    string temp = list[index].OneChange.debtId;
                    if (!remark.Equals(ConfigHelper.GetAppConfig(temp)))
                    {
                        SaveSingleApply(temp);
                        saved = true;
                    }
                }
            }
            probar.Visibility = Visibility.Hidden;
            if (saved)
            {
                MessageBox.Show("保存成功", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}

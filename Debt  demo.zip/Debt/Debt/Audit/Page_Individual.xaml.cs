﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Debt
{
    /// <summary>
    /// Page_Individual.xaml 的交互逻辑
    /// </summary>
    public partial class Page_Individual : Page
    {
        private UserInfo user;
        private string tempPhone;
        private string tempDepartment;
        private string tempName;
        private string tempCompany;
        private Win_Audit parent;
        private List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
        public Page_Individual(UserInfo user, Win_Audit parent)
        {
            this.user = user;
            this.parent = parent;
            InitializeComponent();
        }

        private void ShowUserInfo()
        {
            Tbx_Name.Text = user.name;
            //Tbx_Company.Text = user.companyName;
            Tbx_Department.Text = user.department;
            Tbx_Rank.Text = user.auditRank;
            Tbx_ContactInfo.Text = user.phone;
        }

        public async Task GetCompanyName()
        {
            try
            {
                ShowUserInfo();
                list.Clear();
                Tbx_Company.Items.Clear();
                await new HttpTask().data("token", user.token)
                    .postAsync(Url.GetCompanies, OnSucceed_GetList, OnFailed_GetList);
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed_GetList(string result)
        {
            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                probar.Visibility = Visibility.Hidden;
                return;
            }
            probar.Visibility = Visibility.Hidden;
            
            var companylist = ListCompany.JsonStrToList(result);
            if (companylist.data.Count <= 0)
            {
                list.Add(new KeyValuePair<string, string>(user.companyName, user.companyId));
                Tbx_Company.Items.Add(user.companyName);
                Tbx_Company.Text = user.companyName;
                return;
            }
            else
            {
                foreach (var item in companylist.data)
                {
                    list.Add(new KeyValuePair<string, string>(item.name, item.id));
                    Tbx_Company.Items.Add(item.name);
                }
                Tbx_Company.Text = user.companyName;
            }

        }

        public void OnFailed_GetList()
        {
            list.Add(new KeyValuePair<string, string>(user.companyName, user.companyId));
            probar.Visibility = Visibility.Hidden;
            Tbx_Company.Items.Add(user.companyName);
            Tbx_Company.Text = user.companyName;
            MessageBox.Show("请检查网络状况或本机防火墙设置", "加载申请记录失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Btn_Edit_Click(object sender, RoutedEventArgs e)
        {
            ChangeStyle();
        }

        void ChangeStyle()
        {
            Tbx_Name.Background = Brushes.White;
            Tbx_Name.BorderBrush = Brushes.Gray;
            Tbx_Name.BorderThickness = new Thickness(1, 1, 1, 1);
            Tbx_Name.IsReadOnly = false;
            Tbx_Department.Background = Brushes.White;
            Tbx_Department.BorderBrush = Brushes.Gray;
            Tbx_Department.BorderThickness = new Thickness(1, 1, 1, 1);
            Tbx_Department.IsReadOnly = false;
            Tbx_Company.Background = Brushes.White;
            Tbx_Company.BorderBrush = Brushes.Gray;
            Tbx_Company.BorderThickness = new Thickness(1, 1, 1, 1);
            Tbx_Company.IsEnabled = true;
            Tbx_Company.IsReadOnly = false;
            Tbx_ContactInfo.Background = Brushes.White;
            Tbx_ContactInfo.BorderBrush = Brushes.Gray;
            Tbx_ContactInfo.BorderThickness = new Thickness(1, 1, 1, 1);
            Tbx_ContactInfo.IsReadOnly = false;
        }

        private async void Btn_Save_Click(object sender, RoutedEventArgs e)
        {
            probar.Visibility = Visibility.Visible;
            await SubmitChangeInfo();
        }

        private async Task SubmitChangeInfo()
        {
            if (tempCompany.Equals(user.companyName) && tempPhone.Equals(user.phone) && tempDepartment.Equals(user.department) && tempName.Equals(user.name))
            {
                probar.Visibility = Visibility.Hidden;
                SaveStyle();
                return;
            }

            if (Tbx_Company.Text.Equals(string.Empty))
            {
                MessageBox.Show("请选择公司", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (Tbx_ContactInfo.Text.Equals(string.Empty))
            {
                MessageBox.Show("请输入联系方式", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (Tbx_Department.Text.Equals(string.Empty))
            {
                MessageBox.Show("请输入部门名称", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (Tbx_Name.Text.Equals(string.Empty))
            {
                MessageBox.Show("请输入用户名", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            tempCompany = Tbx_Company.Text;
            tempPhone = Tbx_ContactInfo.Text;
            tempDepartment = Tbx_Department.Text;
            tempName = Tbx_Name.Text;

            try
            {
                ShowUserInfo();
                await new HttpTask().data("name", tempName)
                    .data("company", tempCompany)
                    .data("phone", tempPhone)
                    .data("department", tempDepartment)
                    .data("token", user.token)
                    .postAsync(Url.ChangeUserInfo, OnSucceed_ChangeInfo, OnFailed_ChangeInfo);
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                SaveStyle();
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed_ChangeInfo(string result)
        {
            probar.Visibility = Visibility.Hidden;
            SaveStyle();

            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                return;
            }
            
            foreach (var item in list)
            {
                if (item.Key == tempCompany)
                {
                    user.companyId =parent.User.companyId= item.Value;
                    break;
                }
            }
            parent.User.companyName =user.companyName = tempCompany;
            parent.User.phone = user.phone = tempPhone;
            parent.User.department = user.department = tempDepartment;
            parent.User.name = user.name = tempName;

            MessageBox.Show("个人信息修改成功", "消息提示", MessageBoxButton.OK, MessageBoxImage.Information);

        }

        public void OnFailed_ChangeInfo()
        {
            probar.Visibility = Visibility.Hidden;
            SaveStyle();
            MessageBox.Show("请检查网络状况或本机防火墙设置", "修改个人信息失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        void SaveStyle()
        {
            Tbx_Name.Background = Brushes.Transparent;
            Tbx_Name.BorderBrush = Brushes.Transparent;
            Tbx_Name.BorderThickness = new Thickness(0, 0, 0, 0);
            Tbx_Name.IsReadOnly = true;
            Tbx_Department.Background = Brushes.Transparent;
            Tbx_Department.BorderBrush = Brushes.Transparent;
            Tbx_Department.BorderThickness = new Thickness(0, 0, 0, 0);
            Tbx_Department.IsReadOnly = true;
            Tbx_Company.Background = Brushes.Transparent;
            Tbx_Company.BorderBrush = Brushes.Transparent;
            Tbx_Company.BorderThickness = new Thickness(0, 0, 0, 0);
            Tbx_Company.IsEnabled = false;
            Tbx_Company.IsReadOnly = true;
            Tbx_ContactInfo.Background = Brushes.Transparent;
            Tbx_ContactInfo.BorderBrush = Brushes.Transparent;
            Tbx_ContactInfo.BorderThickness = new Thickness(0, 0, 0, 0);
            Tbx_ContactInfo.IsReadOnly = true;
        }

        private void Btn_SetPwd_Click(object sender, RoutedEventArgs e)
        {
            ModifySelfPsd();
        }

        private async Task ModifySelfPsd()
        {
            if (PsdBox_Old.Password.Equals(string.Empty))
            {
                MessageBox.Show("请输入原密码", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (PsdBox_New.Password.Equals(string.Empty) || PsdBox_Again.Password.Equals(string.Empty))
            {
                MessageBox.Show("请输入新密码", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (!PsdBox_New.Password.Equals(PsdBox_Again.Password))
            {
                MessageBox.Show("请确认两次输入的密码是否一致", "温馨提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string oldPsd = PsdBox_Old.Password;
            string newPsd = PsdBox_New.Password;

            try
            {
                proBar.Visibility = Visibility.Visible;
                await new HttpTask().data("oldPass", oldPsd)
                    .data("newPass", newPsd)
                    .data("token", user.token)
                    .postAsync(Url.GetCompanies, OnSucceed_SetPassword, OnFailed_SetPassword);
            }
            catch (Exception ex)
            {
                proBar.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed_SetPassword(string result)
        {
            proBar.Visibility = Visibility.Hidden;

            MessageBox.Show("密码修改成功，请重新登录", "消息提示", MessageBoxButton.OK, MessageBoxImage.Information);
            parent.Close();
            //关闭当前窗口，返回到登录界面     

        }

        public void OnFailed_SetPassword()
        {
            proBar.Visibility = Visibility.Hidden;
            MessageBox.Show("请检查网络状况或本机防火墙设置", "修改密码失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Btn_Reset_Click(object sender, RoutedEventArgs e)
        {
            PsdBox_Old.Clear();
            PsdBox_New.Clear();
            PsdBox_Again.Clear();
        }


    }
}

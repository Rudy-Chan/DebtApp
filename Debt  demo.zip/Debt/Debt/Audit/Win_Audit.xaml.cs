﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Debt
{
    /// <summary>
    /// Win_Audit.xaml 的交互逻辑
    /// </summary>
    public partial class Win_Audit : Window
    {
        private string token = "0002|784e540ad79cb80e9d6fb762f0528cdf";
        private UserInfo user = new UserInfo("0002", @"\u8d22\u52a1\u90e8", "11", "1", @"\u6b66\u6c49\u8f66\u90fd\u96c6\u56e2\u6709\u9650\u516c\u53f8", @"\u6d4b\u8bd5", "15623202868", "2", "0002|784e540ad79cb80e9d6fb762f0528cdf");
        private Page_Checked page_checked;
        private Page_Applied page_applied;
        private Page_Changed page_changed;
        private Page_Pay page_pay;
        private Page_Receive page_receive;
        private Page_OperationLog page_operationlog;
        private Page_Individual page_individual;

        public UserInfo User
        {
            get { return user; }
            set { user = value; }
        }

        public Win_Audit()
        {
            InitializeComponent();
        }

        private void Heading_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Btn_Skin_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Min_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Btn_Max_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState != WindowState.Normal)
            {
                WindowState = WindowState.Normal;
            }
            else
                WindowState = WindowState.Maximized;
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private async void Tree_Checked_Selected(object sender, RoutedEventArgs e)
        {
            if (page_checked == null)
            {
                page_checked = new Page_Checked(token);
            }
            page_checked.Lab_Info.Visibility= Visibility.Hidden;
            page_checked.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_checked };
            await page_checked.GetRemoteAuditRecord();
        }

        private async void Tree_Applied_Selected(object sender, RoutedEventArgs e)
        {
            if (page_applied == null)
            {
                page_applied = new Page_Applied(token);
            }
            page_applied.Lab_Info.Visibility = Visibility.Hidden;
            page_applied.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_applied };
            await page_applied.GetRemoteApplyRecord();
        }

        private async void Tree_Changed_Selected(object sender, RoutedEventArgs e)
        {
            if (page_changed == null)
            {
                page_changed = new Page_Changed(token);
            }
            page_changed.Lab_Info.Visibility = Visibility.Hidden;
            page_changed.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_changed };
            await page_changed.GetRemoteApplyRecord();
        }

        private async void Tree_Pay_Selected(object sender, RoutedEventArgs e)
        {
            if (page_pay == null)
            {
                page_pay = new Page_Pay(token);
            }
            page_pay.Lab_Info.Visibility = Visibility.Hidden;
            page_pay.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_pay };
            await page_pay.GetRemoteApplyRecord();
        }

        private async void Tree_Receive_Selected(object sender, RoutedEventArgs e)
        {
            if (page_receive == null)
            {
                page_receive = new Page_Receive(token);
            }
            page_receive.Lab_Info.Visibility = Visibility.Hidden;
            page_receive.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_receive };
            await page_receive.GetRemoteApplyRecord();
        }

        private async void Tree_OperationLog_Selected(object sender, RoutedEventArgs e)
        {
            if (page_operationlog == null)
            {
                page_operationlog = new Page_OperationLog(token);
            }
            page_operationlog.Lab_Info.Visibility = Visibility.Hidden;
            page_operationlog.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_operationlog };
            await page_operationlog.GetUserOperationLog();
        }

        private async void Tree_Individual_Selected(object sender, RoutedEventArgs e)
        {
            if (page_individual == null)
            {
                page_individual = new Page_Individual(user, this);
            }
            page_individual.probar.Visibility = Visibility.Visible;
            Dynamic_Page.Content = new Frame() { Content = page_individual };
            await page_individual.GetCompanyName();
        }

        private void Tree_Logout_Selected(object sender, RoutedEventArgs e)
        {

        }

        
    }
}

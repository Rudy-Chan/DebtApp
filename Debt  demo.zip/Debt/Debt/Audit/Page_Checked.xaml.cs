﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Debt
{
    /// <summary>
    /// Page_Checked.xaml 的交互逻辑
    /// </summary>
    public partial class Page_Checked : Page
    {
        private string token;
        private List<Data_AuditItem> list = new List<Data_AuditItem>();
        public Page_Checked(string token)
        {
            this.token = token;
            InitializeComponent();
        }

        private async void Dg_DebtChecked_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Dg_DebtChecked.SelectedItem != null)
            {
                auditFile.SupportId = ((Data_AuditItem)Dg_DebtChecked.SelectedItem).OneAudit.supportId;
                auditFile.Token = token;
                auditFile.probarFile.Visibility = Visibility.Visible;
                await auditFile.GetRemoteFileList();
            }
        }

        public async Task GetRemoteAuditRecord ()
        {
            try
            {
                //selected = 0;
                list.Clear();
                await new HttpTask().data("token", token)
                  .postAsync(Url.GetAuditedList, OnSucceed_GetList, OnFailed_GetList);
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed_GetList(string result)
        {
            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                probar.Visibility = Visibility.Hidden;
                return;
            }
            probar.Visibility = Visibility.Hidden;
            var auditlist = AuditRecord.JsonStrToList(result);
            Dg_DebtChecked.ItemsSource = null;
            if (auditlist.data.Count <= 0)
            {
                Lab_Info.Content = "没有记录";
                Lab_Info.Visibility = Visibility.Visible;
                list.Clear();
            }
            else
            {
                foreach (var item in auditlist.data)
                {
                    string temp = "其他";
                    switch(item.supportId[0])
                    {
                        case 'A':temp = "A";break;
                        case 'C': temp = "C"; break;
                        case 'P': temp = "P"; break;
                        case 'R': temp = "R"; break;
                        default:break;
                    }
                    list.Add(new Data_AuditItem(temp, item));
                }
            }
            MainViewModel<Data_AuditItem> model = new MainViewModel<Data_AuditItem>(list);
            DataContext = model;
            Dg_DebtChecked.ItemsSource = model.FakeSource;
            Dg_DebtChecked.Items.Refresh();
        }

        public void OnFailed_GetList()
        {
            Dg_DebtChecked.ItemsSource = null;
            probar.Visibility = Visibility.Hidden;
            list.Clear();
            Lab_Info.Content = "没有记录";

            MessageBox.Show("请检查网络状况或本机防火墙设置", "加载审核记录失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }


    }
}

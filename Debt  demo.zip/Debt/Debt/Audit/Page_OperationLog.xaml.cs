﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Debt
{
    /// <summary>
    /// Page_OperationLog.xaml 的交互逻辑
    /// </summary>
    public partial class Page_OperationLog : Page
    {
        private string token;
        private List<Operation> list = new List<Operation>();
        public Page_OperationLog(string token)
        {
            this.token = token;
            InitializeComponent();
        }

        public async Task GetUserOperationLog(string page = "1")
        {
            string startTime = Convert.ToString(Dp_TimeStart.SelectedDate); ;
            string endTime = Convert.ToString(Dp_TimeEnd.SelectedDate);

            try
            {
                list.Clear();
                await new HttpTask().data("token", token)
                    .data("page", page)
                    .data("rows", "30")
                    .postAsync(Url.GetOperationLog, OnSucceed_GetList, OnFailed_GetList);
            }
            catch (Exception ex)
            {
                probar.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message, "异常提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSucceed_GetList(string result)
        {
            if (Json.JsonStrToObject(result) != 0)
            {
                Error_Msg.JsonStrToObject(result);
                probar.Visibility = Visibility.Hidden;
                return;
            }
            probar.Visibility = Visibility.Hidden;
            var operationlog = OperationLog.JsonStrToList(result);
            Dg_OperationLog.ItemsSource = null;
            if (operationlog.data.Count <= 0)
            {
                Lab_Info.Content = "没有记录";
                Lab_Info.Visibility = Visibility.Visible;
                list.Clear();
            }
            else
            {
                foreach (var item in operationlog.data)
                {
                    list.Add(item);
                }
            }
            Lab_Info.Visibility = Visibility.Hidden;
            MainViewModel<Operation> model = new MainViewModel<Operation>(list, Convert.ToInt32(operationlog.page), Convert.ToInt32(operationlog.totalPage), this);
            DataContext = model;
            Dg_OperationLog.ItemsSource = model.FakeSource;
            Dg_OperationLog.Items.Refresh();
        }

        public void OnFailed_GetList()
        {
            Dg_OperationLog.ItemsSource = null;
            probar.Visibility = Visibility.Hidden;
            list.Clear();
            Lab_Info.Content = "没有记录";

            MessageBox.Show("请检查网络状况或本机防火墙设置", "加载申请记录失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Btn_Query_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Export_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
